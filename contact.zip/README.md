"# Stanley's Residency" 
